import { useState, useEffect } from 'react';
import { api } from '../api.js';

const ALL_PERMS = [
  { key: 'manageRows',    label: 'Manage Rows' },
  { key: 'editCells',     label: 'Edit Cells' },
  { key: 'manageColumns', label: 'Manage Columns' },
  { key: 'manageUsers',   label: 'Manage Users' },
  { key: 'viewLogs',      label: 'View Logs' },
];

function Modal({ title, onClose, children, footer }) {
  return (
    <div className="modal-overlay">
      <div className="modal">
        <div className="modal-header">
          <span className="modal-title">{title}</span>
          <button onClick={onClose} style={{ background: 'none', border: 'none', fontSize: 20, color: 'var(--text-muted)' }}>✕</button>
        </div>
        <div className="modal-body">{children}</div>
        {footer && <div className="modal-footer">{footer}</div>}
      </div>
    </div>
  );
}

export default function UserManagement({ currentUser }) {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');

  // Modals
  const [showAdd, setShowAdd] = useState(false);
  const [showPwd, setShowPwd] = useState(null);  // username
  const [showPerms, setShowPerms] = useState(null); // user obj
  const [showRename, setShowRename] = useState(null); // username

  // Forms
  const [addForm, setAddForm] = useState({ username: '', password: '', role: 'user' });
  const [pwdForm, setPwdForm] = useState({ password: '', confirm: '' });
  const [newUsername, setNewUsername] = useState('');
  const [permsEdit, setPermsEdit] = useState({});

  async function load() {
    try {
      const d = await api.get('/users');
      setUsers(d.users || []);
    } catch {}
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  function flash(m, isErr = false) {
    if (isErr) setErr(m); else setMsg(m);
    setTimeout(() => { setMsg(''); setErr(''); }, 3000);
  }

  async function addUser() {
    try {
      await api.post('/users', addForm);
      setAddForm({ username: '', password: '', role: 'user' });
      setShowAdd(false);
      flash('User created');
      load();
    } catch (e) { flash(e.message, true); }
  }

  async function changePassword() {
    if (pwdForm.password !== pwdForm.confirm) { flash('Passwords do not match', true); return; }
    try {
      await api.put(`/users/${showPwd}/password`, { password: pwdForm.password });
      setPwdForm({ password: '', confirm: '' });
      setShowPwd(null);
      flash('Password changed');
    } catch (e) { flash(e.message, true); }
  }

  async function renameUser() {
    try {
      await api.put(`/users/${showRename}/rename`, { newUsername });
      setShowRename(null);
      flash('User renamed');
      load();
    } catch (e) { flash(e.message, true); }
  }

  async function savePerms() {
    try {
      await api.put(`/users/${showPerms.username}/permissions`, { permissions: permsEdit });
      setShowPerms(null);
      flash('Permissions saved');
      load();
    } catch (e) { flash(e.message, true); }
  }

  async function deleteUser(u) {
    if (!confirm(`Delete user "${u}"?`)) return;
    try {
      await api.delete(`/users/${u}`);
      flash('User deleted');
      load();
    } catch (e) { flash(e.message, true); }
  }

  if (loading) return <div style={{ padding: 40, textAlign: 'center', color: 'var(--text-muted)' }}>Loading…</div>;

  return (
    <div style={{ padding: 24 }}>
      <div style={{ marginBottom: 20 }}>
        <h1 style={{ fontSize: 22, fontWeight: 700, marginBottom: 4 }}>User Management</h1>
        <p style={{ color: 'var(--text-muted)' }}>{users.length} user{users.length !== 1 ? 's' : ''}</p>
      </div>

      {msg && <div className="alert alert-success">{msg}</div>}
      {err && <div className="alert alert-error">{err}</div>}

      <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 16 }}>
        <button className="btn btn-primary btn-sm" onClick={() => setShowAdd(true)}>+ Add User</button>
      </div>

      <div className="card" style={{ overflow: 'hidden' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
          <thead>
            <tr style={{ background: 'var(--bg)', borderBottom: '2px solid var(--border)' }}>
              {['Username', 'Role', 'Permissions', 'Actions'].map(h => (
                <th key={h} style={{ padding: '10px 16px', textAlign: 'left', fontWeight: 600, color: 'var(--text-muted)' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {users.map(u => (
              <tr key={u.username} style={{ borderBottom: '1px solid var(--border)' }}>
                <td style={{ padding: '12px 16px', fontWeight: 500 }}>
                  {u.username}
                  {u.username === currentUser?.username && <span className="badge badge-blue" style={{ marginLeft: 8, fontSize: 10 }}>You</span>}
                </td>
                <td style={{ padding: '12px 16px' }}>
                  <span className={`badge ${u.role === 'admin' ? 'badge-blue' : 'badge-gray'}`}>{u.role}</span>
                </td>
                <td style={{ padding: '12px 16px' }}>
                  {u.role === 'admin'
                    ? <span style={{ color: 'var(--text-muted)', fontSize: 12 }}>All permissions</span>
                    : (
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                        {ALL_PERMS.filter(p => u.permissions?.[p.key]).map(p => (
                          <span key={p.key} className="badge badge-green" style={{ fontSize: 10 }}>{p.label}</span>
                        ))}
                        {!ALL_PERMS.some(p => u.permissions?.[p.key]) && <span style={{ color: 'var(--text-muted)', fontSize: 12 }}>None</span>}
                      </div>
                    )
                  }
                </td>
                <td style={{ padding: '12px 16px' }}>
                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                    <button className="btn btn-sm btn-secondary" onClick={() => { setShowPwd(u.username); setPwdForm({ password: '', confirm: '' }); }}>Password</button>
                    <button className="btn btn-sm btn-secondary" onClick={() => { setShowRename(u.username); setNewUsername(u.username); }}>Rename</button>
                    {u.role !== 'admin' && <button className="btn btn-sm btn-secondary" onClick={() => { setShowPerms(u); setPermsEdit({ ...u.permissions }); }}>Permissions</button>}
                    {u.username !== currentUser?.username && <button className="btn btn-sm btn-danger" onClick={() => deleteUser(u.username)}>Delete</button>}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add User */}
      {showAdd && (
        <Modal title="Add User" onClose={() => setShowAdd(false)} footer={
          <>
            <button className="btn btn-secondary" onClick={() => setShowAdd(false)}>Cancel</button>
            <button className="btn btn-primary" onClick={addUser}>Create</button>
          </>
        }>
          <div className="form-group">
            <label>Username</label>
            <input className="form-control" value={addForm.username} onChange={e => setAddForm(p => ({ ...p, username: e.target.value }))} placeholder="username" autoFocus />
          </div>
          <div className="form-group">
            <label>Password</label>
            <input className="form-control" type="password" value={addForm.password} onChange={e => setAddForm(p => ({ ...p, password: e.target.value }))} />
          </div>
          <div className="form-group">
            <label>Role</label>
            <select className="form-control" value={addForm.role} onChange={e => setAddForm(p => ({ ...p, role: e.target.value }))}>
              <option value="user">User</option>
              <option value="admin">Admin</option>
            </select>
          </div>
        </Modal>
      )}

      {/* Change Password */}
      {showPwd && (
        <Modal title={`Change Password: ${showPwd}`} onClose={() => setShowPwd(null)} footer={
          <>
            <button className="btn btn-secondary" onClick={() => setShowPwd(null)}>Cancel</button>
            <button className="btn btn-primary" onClick={changePassword}>Save</button>
          </>
        }>
          <div className="form-group">
            <label>New Password</label>
            <input className="form-control" type="password" value={pwdForm.password} onChange={e => setPwdForm(p => ({ ...p, password: e.target.value }))} autoFocus />
          </div>
          <div className="form-group">
            <label>Confirm Password</label>
            <input className="form-control" type="password" value={pwdForm.confirm} onChange={e => setPwdForm(p => ({ ...p, confirm: e.target.value }))} />
          </div>
        </Modal>
      )}

      {/* Rename */}
      {showRename && (
        <Modal title={`Rename: ${showRename}`} onClose={() => setShowRename(null)} footer={
          <>
            <button className="btn btn-secondary" onClick={() => setShowRename(null)}>Cancel</button>
            <button className="btn btn-primary" onClick={renameUser}>Rename</button>
          </>
        }>
          <div className="form-group">
            <label>New Username</label>
            <input className="form-control" value={newUsername} onChange={e => setNewUsername(e.target.value)} autoFocus />
          </div>
        </Modal>
      )}

      {/* Permissions */}
      {showPerms && (
        <Modal title={`Permissions: ${showPerms.username}`} onClose={() => setShowPerms(null)} footer={
          <>
            <button className="btn btn-secondary" onClick={() => setShowPerms(null)}>Cancel</button>
            <button className="btn btn-primary" onClick={savePerms}>Save</button>
          </>
        }>
          {ALL_PERMS.map(p => (
            <label key={p.key} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 0', cursor: 'pointer', borderBottom: '1px solid var(--border)' }}>
              <input type="checkbox" checked={!!permsEdit[p.key]} onChange={e => setPermsEdit(prev => ({ ...prev, [p.key]: e.target.checked }))} style={{ width: 16, height: 16 }} />
              <span style={{ fontWeight: 500 }}>{p.label}</span>
            </label>
          ))}
        </Modal>
      )}
    </div>
  );
}
