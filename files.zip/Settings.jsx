import { useState, useEffect } from 'react';
import { api } from '../api.js';

function Section({ title, children }) {
  return (
    <div style={{ marginBottom: 24 }}>
      <h2 style={{ fontSize: 15, fontWeight: 700, marginBottom: 14, paddingBottom: 8, borderBottom: '2px solid var(--border)' }}>{title}</h2>
      {children}
    </div>
  );
}

export default function Settings({ user }) {
  const isAdmin = user?.role === 'admin';
  const [config, setConfig] = useState({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');

  useEffect(() => {
    api.get('/config').then(d => { setConfig(d.config || {}); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  function set(k, v) { setConfig(p => ({ ...p, [k]: v })); }

  function flash(m, isErr = false) {
    if (isErr) { setErr(m); setMsg(''); } else { setMsg(m); setErr(''); }
    setTimeout(() => { setMsg(''); setErr(''); }, 4000);
  }

  async function save() {
    setSaving(true);
    try {
      await api.post('/config', { config });
      flash('Configuration saved. Restart server to apply changes.');
    } catch (e) { flash(e.message, true); }
    setSaving(false);
  }

  async function testEmail() {
    setTesting(true);
    try {
      const d = await api.post('/email/test', { config });
      flash(d.message || 'Test email sent!');
    } catch (e) { flash(e.message, true); }
    setTesting(false);
  }

  if (loading) return <div style={{ padding: 40, textAlign: 'center', color: 'var(--text-muted)' }}>Loading…</div>;

  const Field = ({ label, k, type = 'text', placeholder = '' }) => (
    <div className="form-group">
      <label style={{ fontSize: 13 }}>{label}</label>
      <input className="form-control" type={type} value={config[k] || ''} onChange={e => set(k, e.target.value)} placeholder={placeholder} disabled={!isAdmin} />
    </div>
  );

  const Toggle = ({ label, k, desc }) => (
    <label style={{ display: 'flex', alignItems: 'flex-start', gap: 12, padding: '10px 0', cursor: isAdmin ? 'pointer' : 'default', borderBottom: '1px solid var(--border)' }}>
      <input type="checkbox" checked={config[k] === 'true'} onChange={e => set(k, e.target.checked ? 'true' : 'false')} disabled={!isAdmin} style={{ marginTop: 3, width: 16, height: 16 }} />
      <div>
        <div style={{ fontWeight: 500, fontSize: 13 }}>{label}</div>
        {desc && <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>{desc}</div>}
      </div>
    </label>
  );

  return (
    <div style={{ padding: 24, maxWidth: 700 }}>
      <div style={{ marginBottom: 20 }}>
        <h1 style={{ fontSize: 22, fontWeight: 700, marginBottom: 4 }}>Settings</h1>
        <p style={{ color: 'var(--text-muted)' }}>{isAdmin ? 'Configure server settings' : 'View-only — contact an admin to change settings'}</p>
      </div>

      {msg && <div className="alert alert-success">{msg}</div>}
      {err && <div className="alert alert-error">{err}</div>}

      <Section title="Server">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 16px' }}>
          <Field label="Port" k="PORT" placeholder="4000" />
          <Field label="Node Environment" k="NODE_ENV" placeholder="development" />
        </div>
        <Field label="CORS Origin (comma-separated)" k="CORS_ORIGIN" placeholder="https://example.com,https://app.example.com" />
        <Field label="Session Timeout (ms)" k="SESSION_TIMEOUT_MS" placeholder="900000" />
      </Section>

      <Section title="JWT / Authentication">
        <Field label="JWT Secret" k="JWT_SECRET" type="password" placeholder="strong-secret-key" />
        <Field label="JWT Expires In" k="JWT_EXPIRES_IN" placeholder="8h" />
      </Section>

      <Section title="SMTP / Email">
        <Toggle k="SMTP_ENABLED" label="Enable SMTP" desc="Required for 2FA and email notifications" />
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '0 16px', marginTop: 12 }}>
          <Field label="SMTP Host" k="SMTP_HOST" placeholder="smtp.gmail.com" />
          <Field label="SMTP Port" k="SMTP_PORT" placeholder="587" />
        </div>
        <div className="form-group">
          <label style={{ fontSize: 13 }}>Security</label>
          <select className="form-control" value={config.SMTP_SECURE || 'false'} onChange={e => set('SMTP_SECURE', e.target.value)} disabled={!isAdmin}>
            <option value="false">STARTTLS (port 587)</option>
            <option value="true">SSL/TLS (port 465)</option>
            <option value="none">None (no encryption)</option>
          </select>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 16px' }}>
          <Field label="SMTP User" k="SMTP_USER" placeholder="user@gmail.com" />
          <Field label="SMTP Password" k="SMTP_PASSWORD" type="password" placeholder="••••••" />
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 16px' }}>
          <Field label="From Name" k="SMTP_FROM_NAME" placeholder="PP-Network" />
          <Field label="From Email" k="SMTP_FROM_EMAIL" placeholder="noreply@example.com" />
        </div>
        <Field label="Test Recipient Email" k="SMTP_TEST_TO_EMAIL" placeholder="admin@example.com" />
        {isAdmin && (
          <button className="btn btn-secondary btn-sm" onClick={testEmail} disabled={testing}>
            {testing ? 'Sending…' : '📧 Send Test Email'}
          </button>
        )}
      </Section>

      <Section title="SSO / SAML">
        <Toggle k="SSO_ENABLED" label="Enable SSO" desc="Google Workspace / G Suite SAML integration" />
        <Field label="Entity ID" k="SSO_ENTITY_ID" />
        <Field label="Sign-On URL" k="SSO_SIGN_ON_URL" />
        <Field label="Sign-Out URL" k="SSO_SIGN_OUT_URL" />
        <Field label="SP Entity ID" k="SP_ENTITY_ID" />
        <Field label="ACS URL" k="ACS_URL" />
      </Section>

      {isAdmin && (
        <div style={{ display: 'flex', justifyContent: 'flex-end', paddingTop: 8 }}>
          <button className="btn btn-primary" onClick={save} disabled={saving}>
            {saving ? 'Saving…' : 'Save Configuration'}
          </button>
        </div>
      )}
    </div>
  );
}
