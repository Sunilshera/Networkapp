import { useState, useEffect, useRef } from 'react';
import { api } from '../api.js';

const PROTECTED = ['Location', 'Password'];

function PasswordCell({ value, rowId, colName, canEdit, onSaved }) {
  const [show, setShow] = useState(false);
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState(value);
  const [saving, setSaving] = useState(false);

  async function save() {
    if (val === value) { setEditing(false); return; }
    setSaving(true);
    try {
      await api.put(`/rows/${rowId}`, { [colName]: val });
      onSaved();
    } catch {}
    setSaving(false);
    setEditing(false);
  }

  if (editing) {
    return (
      <div style={{ display: 'flex', gap: 4 }}>
        <input className="form-control" style={{ padding: '4px 8px', fontSize: 12, minWidth: 120 }}
          value={val} onChange={e => setVal(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter') save(); if (e.key === 'Escape') setEditing(false); }} autoFocus />
        <button className="btn btn-sm btn-primary" onClick={save} disabled={saving}>✓</button>
        <button className="btn btn-sm btn-secondary" onClick={() => setEditing(false)}>✕</button>
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
      <span style={{ fontFamily: 'monospace', letterSpacing: show ? 0 : 2 }}>{show ? value : '••••••'}</span>
      <button onClick={() => setShow(s => !s)} style={{ background: 'none', border: 'none', padding: 2, color: 'var(--text-muted)', fontSize: 11 }}>{show ? '🙈' : '👁'}</button>
      {canEdit && <button onClick={() => setEditing(true)} style={{ background: 'none', border: 'none', padding: 2, color: 'var(--text-muted)', fontSize: 11 }}>✏️</button>}
    </div>
  );
}

function EditableCell({ value, rowId, colName, canEdit, onSaved }) {
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState(value);
  const [saving, setSaving] = useState(false);

  async function save() {
    if (val === value) { setEditing(false); return; }
    setSaving(true);
    try {
      await api.put(`/rows/${rowId}`, { [colName]: val });
      onSaved();
    } catch {}
    setSaving(false);
    setEditing(false);
  }

  if (!canEdit) return <span>{value}</span>;

  if (editing) {
    return (
      <div style={{ display: 'flex', gap: 4 }}>
        <input className="form-control" style={{ padding: '4px 8px', fontSize: 12, minWidth: 100 }}
          value={val} onChange={e => setVal(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter') save(); if (e.key === 'Escape') setEditing(false); }} autoFocus />
        <button className="btn btn-sm btn-primary" onClick={save} disabled={saving}>✓</button>
        <button className="btn btn-sm btn-secondary" onClick={() => setEditing(false)}>✕</button>
      </div>
    );
  }

  return (
    <span style={{ cursor: 'pointer', padding: '2px 4px', borderRadius: 4 }}
      onDoubleClick={() => setEditing(true)}
      title="Double-click to edit">
      {value || <span style={{ color: 'var(--text-muted)', fontStyle: 'italic' }}>—</span>}
    </span>
  );
}

export default function NetworkTable({ user }) {
  const perms = user?.permissions || {};
  const isAdmin = user?.role === 'admin';
  const canManageRows = isAdmin || perms.manageRows;
  const canManageCols = isAdmin || perms.manageColumns;
  const canEdit = isAdmin || perms.editCells;

  const [data, setData] = useState({ columns: [], rows: [] });
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showAddRow, setShowAddRow] = useState(false);
  const [showAddCol, setShowAddCol] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [showArchive, setShowArchive] = useState(false);
  const [newColName, setNewColName] = useState('');
  const [newRowData, setNewRowData] = useState({});
  const [importText, setImportText] = useState('');
  const [msg, setMsg] = useState('');
  const [archive, setArchive] = useState([]);

  async function load() {
    try {
      const d = await api.get('/table');
      setData(d);
    } catch {}
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  function flash(m) { setMsg(m); setTimeout(() => setMsg(''), 3000); }

  const filtered = data.rows.filter(row =>
    data.columns.some(col => String(row[col] || '').toLowerCase().includes(search.toLowerCase()))
  );

  async function addRow() {
    try {
      await api.post('/rows', newRowData);
      setNewRowData({});
      setShowAddRow(false);
      flash('Row added successfully');
      load();
    } catch (e) { flash(e.message); }
  }

  async function deleteRow(id) {
    if (!confirm('Delete this row? It can be restored from archive.')) return;
    try {
      await api.delete(`/rows/${id}`);
      flash('Row deleted');
      load();
    } catch (e) { flash(e.message); }
  }

  async function addColumn() {
    if (!newColName.trim()) return;
    try {
      await api.post('/columns', { name: newColName.trim() });
      setNewColName('');
      setShowAddCol(false);
      flash('Column added');
      load();
    } catch (e) { flash(e.message); }
  }

  async function deleteColumn(name) {
    if (!confirm(`Delete column "${name}"?`)) return;
    try {
      await api.delete(`/columns/${encodeURIComponent(name)}`);
      flash('Column deleted');
      load();
    } catch (e) { flash(e.message); }
  }

  async function doImport() {
    try {
      const rows = JSON.parse(importText);
      await api.post('/table/import', { rows });
      setImportText('');
      setShowImport(false);
      flash('Import successful');
      load();
    } catch (e) { flash(e.message); }
  }

  async function loadArchive() {
    const d = await api.get('/table');
    setArchive(d.rowArchive || []);
    setShowArchive(true);
  }

  async function restoreRow(id) {
    try {
      await api.post(`/rows/restore/${id}`);
      flash('Row restored');
      load();
      const d = await api.get('/table');
      setArchive(d.rowArchive || []);
    } catch (e) { flash(e.message); }
  }

  if (loading) return <div style={{ padding: 40, textAlign: 'center', color: 'var(--text-muted)' }}>Loading…</div>;

  return (
    <div style={{ padding: 24 }}>
      {/* Header */}
      <div style={{ marginBottom: 20 }}>
        <h1 style={{ fontSize: 22, fontWeight: 700, marginBottom: 4 }}>Network Table</h1>
        <p style={{ color: 'var(--text-muted)' }}>{data.rows.length} device{data.rows.length !== 1 ? 's' : ''} · {data.columns.length} column{data.columns.length !== 1 ? 's' : ''}</p>
      </div>

      {msg && <div className="alert alert-success">{msg}</div>}

      {/* Toolbar */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 16, flexWrap: 'wrap' }}>
        <input className="form-control" style={{ maxWidth: 260 }} placeholder="Search…" value={search} onChange={e => setSearch(e.target.value)} />
        <div style={{ flex: 1 }} />
        {canManageRows && (
          <>
            <button className="btn btn-secondary btn-sm" onClick={() => setShowImport(true)}>⬆ Import JSON</button>
            <button className="btn btn-secondary btn-sm" onClick={loadArchive}>🗄 Archive</button>
            <button className="btn btn-primary btn-sm" onClick={() => setShowAddRow(true)}>+ Add Row</button>
          </>
        )}
        {canManageCols && <button className="btn btn-secondary btn-sm" onClick={() => setShowAddCol(true)}>+ Add Column</button>}
      </div>

      {/* Table */}
      <div className="card" style={{ overflow: 'hidden' }}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead>
              <tr style={{ background: 'var(--bg)', borderBottom: '2px solid var(--border)' }}>
                <th style={{ padding: '10px 12px', textAlign: 'left', fontWeight: 600, color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>#</th>
                {data.columns.map(col => (
                  <th key={col} style={{ padding: '10px 12px', textAlign: 'left', fontWeight: 600, color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      {col}
                      {canManageCols && !PROTECTED.includes(col) && (
                        <button onClick={() => deleteColumn(col)} style={{ background: 'none', border: 'none', color: '#ef4444', fontSize: 11, padding: '0 2px', lineHeight: 1 }} title="Delete column">✕</button>
                      )}
                    </div>
                  </th>
                ))}
                {canManageRows && <th style={{ padding: '10px 12px', textAlign: 'right', fontWeight: 600, color: 'var(--text-muted)' }}>Actions</th>}
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr><td colSpan={data.columns.length + 2} style={{ padding: 32, textAlign: 'center', color: 'var(--text-muted)' }}>No rows found</td></tr>
              )}
              {filtered.map((row, i) => (
                <tr key={row.id} style={{ borderBottom: '1px solid var(--border)' }}>
                  <td style={{ padding: '10px 12px', color: 'var(--text-muted)', fontFamily: 'monospace', fontSize: 11 }}>{row.id}</td>
                  {data.columns.map(col => (
                    <td key={col} style={{ padding: '10px 12px', maxWidth: 200 }}>
                      {col === 'Password'
                        ? <PasswordCell value={row[col] || ''} rowId={row.id} colName={col} canEdit={canEdit} onSaved={load} />
                        : <EditableCell value={row[col] || ''} rowId={row.id} colName={col} canEdit={canEdit} onSaved={load} />
                      }
                    </td>
                  ))}
                  {canManageRows && (
                    <td style={{ padding: '10px 12px', textAlign: 'right' }}>
                      <button className="btn btn-sm btn-danger" onClick={() => deleteRow(row.id)}>Delete</button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Row Modal */}
      {showAddRow && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <span className="modal-title">Add New Row</span>
              <button onClick={() => setShowAddRow(false)} style={{ background: 'none', border: 'none', fontSize: 20, color: 'var(--text-muted)' }}>✕</button>
            </div>
            <div className="modal-body" style={{ maxHeight: '60vh', overflowY: 'auto' }}>
              {data.columns.map(col => (
                <div key={col} className="form-group">
                  <label>{col}{PROTECTED.includes(col) ? ' *' : ''}</label>
                  <input className="form-control" type={col === 'Password' ? 'password' : 'text'}
                    value={newRowData[col] || ''}
                    onChange={e => setNewRowData(p => ({ ...p, [col]: e.target.value }))}
                    placeholder={`Enter ${col}`} />
                </div>
              ))}
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={() => setShowAddRow(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={addRow}>Add Row</button>
            </div>
          </div>
        </div>
      )}

      {/* Add Column Modal */}
      {showAddCol && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <span className="modal-title">Add New Column</span>
              <button onClick={() => setShowAddCol(false)} style={{ background: 'none', border: 'none', fontSize: 20, color: 'var(--text-muted)' }}>✕</button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label>Column Name</label>
                <input className="form-control" value={newColName} onChange={e => setNewColName(e.target.value)}
                  placeholder="e.g. Contact Person" autoFocus
                  onKeyDown={e => { if (e.key === 'Enter') addColumn(); }} />
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={() => setShowAddCol(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={addColumn}>Add Column</button>
            </div>
          </div>
        </div>
      )}

      {/* Import Modal */}
      {showImport && (
        <div className="modal-overlay">
          <div className="modal" style={{ maxWidth: 560 }}>
            <div className="modal-header">
              <span className="modal-title">Import JSON Rows</span>
              <button onClick={() => setShowImport(false)} style={{ background: 'none', border: 'none', fontSize: 20, color: 'var(--text-muted)' }}>✕</button>
            </div>
            <div className="modal-body">
              <p style={{ color: 'var(--text-muted)', marginBottom: 12, fontSize: 13 }}>Paste a JSON array of row objects. Each must include a <code>Location</code> and <code>Password</code>.</p>
              <textarea className="form-control" rows={8} value={importText} onChange={e => setImportText(e.target.value)}
                placeholder={'[\n  { "Location": "DC1", "Password": "secret", "IP Address": "10.0.0.1" }\n]'} />
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={() => setShowImport(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={doImport}>Import</button>
            </div>
          </div>
        </div>
      )}

      {/* Archive Modal */}
      {showArchive && (
        <div className="modal-overlay">
          <div className="modal" style={{ maxWidth: 700 }}>
            <div className="modal-header">
              <span className="modal-title">Row Archive ({archive.length})</span>
              <button onClick={() => setShowArchive(false)} style={{ background: 'none', border: 'none', fontSize: 20, color: 'var(--text-muted)' }}>✕</button>
            </div>
            <div className="modal-body" style={{ maxHeight: '60vh', overflowY: 'auto' }}>
              {archive.length === 0
                ? <p style={{ color: 'var(--text-muted)', textAlign: 'center' }}>No archived rows</p>
                : archive.map(row => (
                  <div key={row.id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
                    <div>
                      <div style={{ fontWeight: 500 }}>{row.Location || row.id}</div>
                      <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{row.id}</div>
                    </div>
                    <button className="btn btn-sm btn-secondary" onClick={() => restoreRow(row.id)}>Restore</button>
                  </div>
                ))
              }
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={() => setShowArchive(false)}>Close</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
