import { useState, useEffect } from 'react';
import Login from './components/Login.jsx';
import Layout from './components/Layout.jsx';
import NetworkTable from './components/NetworkTable.jsx';
import UserManagement from './components/UserManagement.jsx';
import AuditLogs from './components/AuditLogs.jsx';
import Settings from './components/Settings.jsx';
import { api } from './api.js';

export default function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState('table');

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) { setLoading(false); return; }
    api.get('/me')
      .then(d => setUser(d.user))
      .catch(() => localStorage.removeItem('token'))
      .finally(() => setLoading(false));
  }, []);

  function handleLogin(u) { setUser(u); }

  function handleLogout() {
    localStorage.removeItem('token');
    setUser(null);
  }

  if (loading) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ textAlign: 'center', color: 'var(--text-muted)' }}>Loading…</div>
      </div>
    );
  }

  if (!user) return <Login onLogin={handleLogin} />;

  const isAdmin = user.role === 'admin';
  const perms = user.permissions || {};

  function renderPage() {
    switch (page) {
      case 'table':   return <NetworkTable user={user} />;
      case 'users':   return (isAdmin || perms.manageUsers) ? <UserManagement currentUser={user} /> : <NotAllowed />;
      case 'logs':    return (isAdmin || perms.viewLogs)    ? <AuditLogs />                         : <NotAllowed />;
      case 'settings': return <Settings user={user} />;
      default: return null;
    }
  }

  return (
    <Layout user={user} page={page} setPage={setPage} onLogout={handleLogout}>
      {renderPage()}
    </Layout>
  );
}

function NotAllowed() {
  return (
    <div style={{ padding: 40, textAlign: 'center', color: 'var(--text-muted)' }}>
      <div style={{ fontSize: 40, marginBottom: 12 }}>🔒</div>
      <h2 style={{ fontSize: 18, fontWeight: 600, marginBottom: 6 }}>Access Denied</h2>
      <p>You don't have permission to view this page.</p>
    </div>
  );
}
